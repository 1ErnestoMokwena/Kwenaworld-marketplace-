// Comments Firebase logic
