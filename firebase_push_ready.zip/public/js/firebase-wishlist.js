// Wishlist Firebase logic
