// Sales counter Firebase logic
